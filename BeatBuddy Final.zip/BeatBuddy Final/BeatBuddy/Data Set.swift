//
//  DataSet.swift
//  tesapp1
//
//  Created by Kresna Faza R on 21/03/23.
//

import Foundation

struct nameData  {
    var personName : String
    var songData : [songData]
    var showCard : [Bool]
    var hideCard : [Bool]
    var mutableOffset : [Int]
}

extension nameData {
    init(name: String){
        personName = name
        songData = generateSongFromName(name: name)
        showCard = generateShowCardFlag(count: name.count)
        hideCard = generateHideCardFlag(count: name.count)
        mutableOffset = generateMutableOffset(count: name.count)
    }
}

struct songData : Identifiable {
    let id = UUID()
    let alphabet: String
    let song: String
    let singer: String
    let img : String
}

var songDataSet = [
    "a" : [
        songData(alphabet: "A", song: "A Day in the Life", singer: "The Beatles", img: "a-day-in-the-life"),
        songData(alphabet: "A", song: "Adore You", singer: "Harry Styles", img: "adore-you"),
        songData(alphabet: "A", song: "Afterglow", singer: "Ed Sheeran", img: "afterglow"),
        songData(alphabet: "A", song: "Adu Rayu", singer: "Yovie Widianto, Tulus, Glenn Fredly", img: "adu-rayu"),
        songData(alphabet: "A", song: "Anyone", singer: "Justin Bieber", img: "anyone"),
    ],
    
    "b" : [
        songData(alphabet: "B", song: "Bad Habits", singer: "Ed Sheeran" , img: "bad-habits"),
        songData(alphabet: "B", song: "Blinding Lights", singer: "The Weeknd" , img: "blinding-lights"),
        songData(alphabet: "B", song: "Bohemian Rhapsody", singer: "Queen" , img: "bohemian-rhapsody"),
    ],
    
    "c" : [
        songData(alphabet: "C", song: "Cahaya", singer: "Tulus", img: "cahaya"),
        songData(alphabet: "C", song: "Cheating On You", singer: "Charlie Puth", img: "cheating-on-you"),
        songData(alphabet: "C", song: "Cinta dan Rahasia", singer: "Yura Yunita, Glenn Fredly", img: "cheating-on-you"),
        songData(alphabet: "C", song: "Cinta Melulu", singer: "Efek Rumah Kaca", img: "cinta-melulu"),
    ],
    
    "d" : [
        songData(alphabet: "D", song: "Dark Red", singer: "Steve Lacy" , img: "dark-red"),
        songData(alphabet: "D", song: "drivers license" , singer: "Olivia Rodrigo" , img: "drivers-license"),
        songData(alphabet: "D", song: "double take", singer: "dhruv" , img: "double-take"),
    ],
    
    "e" : [
        songData(alphabet: "E", song: "Easy on Me", singer: "Adele" , img: "easy-on-me"),
        songData(alphabet: "E", song: "Empty House" , singer: "Gangga" , img: "empty-house"),
        songData(alphabet: "E", song: "Entertain Me", singer: "Ylona Garcia" , img: "double-take"),
        songData(alphabet: "E", song: "Evaluasi" , singer: "Hindia" , img: "evaluasi"),
        songData(alphabet: "E", song: "Everything I Wanted", singer: "Billie Eillish" , img: "everything-i-wanted"),
    ],
    
    "f" : [
        songData(alphabet: "F", song: "Feeling Good", singer: "Michael Bubble", img: "feeling-good"),
        songData(alphabet: "F", song: "Fancy Like", singer: "Walker Hayes", img: "fancy-like"),
        songData(alphabet: "F", song: "Fever", singer: "Dua Lipa ft. Angèle", img: "fever"),
        songData(alphabet: "F", song: "Fine", singer: "Taeyon", img: "fine"),
        songData(alphabet: "F", song: "Flowers", singer: "Miley Cyrus", img: "flowers"),
    ],
    
    "g" : [
        songData(alphabet: "G", song: "Girls Like You", singer: "Maroon 5", img: "girls-like-u"),
        songData(alphabet: "G", song: "Golden Hour", singer: "JVKE", img: "golden-hour"),
        songData(alphabet: "G", song: "good 4 u", singer: "Olivia Rodrigo", img: "good-4-u"),
    ],
    
    "h" : [
        songData(alphabet: "H", song: "Heartsong", singer: "HONNE", img: "girls-like-u"),
        songData(alphabet: "H", song: "Hanya Rindu", singer: "Andmesh Kamaleng", img: "hanya-rindu"),
        songData(alphabet: "H", song: "Happier", singer: "Ed Sheeran", img: "happier"),
        songData(alphabet: "H", song: "Heartless", singer: "The Weeknd", img: "heartless"),
    ],
    
    "i" : [
        songData(alphabet: "I", song: "Intentions", singer: "Justin Bieber ft. Quavo", img: "intentions"),
        songData(alphabet: "I", song: "In My Blood", singer: "Shawn Mendes", img: "in-my-blood"),
        songData(alphabet: "I", song: "I Like Me Better", singer: "Lauv", img: "i-like-me-better"),
        songData(alphabet: "I", song: "Indah Pada Waktunya", singer: "Rizky Febian ft. Aisyah Aziz", img: "indah-pada-waktunya"),
    ],
    
    "j" : [
        songData(alphabet: "J", song: "Januari", singer: "Glenn Fredly", img: "januari"),
        songData(alphabet: "J", song: "Jealous", singer: "Labrinth", img: "jealous"),
        songData(alphabet: "J", song: "Just You", singer: "Teddy Adhitya", img: "just-you"),
    ],
    
    "k" : [
        songData(alphabet: "K", song: "Kill This Love", singer: "Blackpink", img: "kill-this-love"),
        songData(alphabet: "K", song: "Killshot", singer: "Eminem", img: "killshot"),
        songData(alphabet: "K", song: "Kings and Queens", singer: "Ava Max", img: "kings-and-queens"),
        songData(alphabet: "K", song: "Knock Knock", singer: "Twice", img: "knock-knock"),
        songData(alphabet: "K", song: "Kukira Kau Rumah", singer: "Amigdala", img: "kukira-kau-rumah"),
    ],
    
    "l" : [
        songData(alphabet: "L", song: "Love Scenario", singer: "iKon", img: "love-scenario"),
        songData(alphabet: "L", song: "Lathi", singer: "iKon", img: "lathi"),
        songData(alphabet: "L", song: "Lebih Dari Egoku", singer: "iKon", img: "lebih-dari-egoku"),
        songData(alphabet: "L", song: "Love Shot", singer: "EXO", img: "love-shot"),
    ],
    
    "m" : [
        songData(alphabet: "M", song: "My Funny Valentine", singer: "Stories, Bruno Major", img: "my-funny-valentine"),
        songData(alphabet: "M", song: "Moral Of The Story", singer: "Ashe", img: "moral-of-the-story"),
    ],
    
    "n" : [
        songData(alphabet: "N", song: "Nyaman", singer: "Andmesh Kamaleng", img: "nyaman"),
        songData(alphabet: "N", song: "Nonsense", singer: "Sabrina Carpenter", img: "nonsense"),
        songData(alphabet: "N", song: "Not Shy", singer: "ITZY", img: "not-shy"),
        songData(alphabet: "N", song: "No More Dream", singer: "BTS", img: "no-more-dream"),
    ],
    
    "o" : [
        songData(alphabet: "O", song: "OMG", singer: "New Jeans", img: "omg"),
        songData(alphabet: "O", song: "Obsession", singer: "EXO", img: "obsession"),
        songData(alphabet: "O", song: "Out Of Time", singer: "The Weeknd", img: "out-of-time"),
        songData(alphabet: "O", song: "Old Town Road", singer: "Lil Nas X ft. Billy Ray Cyrus", img: "old-town-road"),
    ],
    
    "p" : [
        songData(alphabet: "P", song: "Pandemonium", singer: "NIKI", img: "pandemonium"),
        songData(alphabet: "P", song: "Planet Girl", singer: "jooyoung, pH-1", img: "planet-girl"),
    ],
    
    "q" : [
        songData(alphabet: "Q", song: "Queen Of California", singer: "John Mayer", img: "queen-of-california"),
        songData(alphabet: "Q", song: "Quit Playing Games", singer: "The Backstreet Boys", img: "quit-playing-games"),
    ],
    
    "r" : [
        songData(alphabet: "R", song: "Ruang Sendiri", singer: "Tulus", img: "ruang-sendiri"),
        songData(alphabet: "R", song: "Rapuh", singer: "Agnes Monica", img: "rapuh"),
        songData(alphabet: "R", song: "Ready For It?", singer: "Taylor Swift", img: "ready-for-it"),
        songData(alphabet: "R", song: "Rindu Dalam Hati", singer: "Tulus", img: "rindu-dalam-hati"),
    ],
    
    "s" : [
        songData(alphabet: "S", song: "Soon", singer: "Johnny Yukon", img: "soon"),
        songData(alphabet: "S", song: "Sims", singer: "Lauv", img: "sims"),
        songData(alphabet: "S", song: "she's all i wanna be", singer: "Tate Mcrae", img: "shes-all-i-wanna-be"),
    ],
    
    "t" : [
        songData(alphabet: "T", song: "Tak Mungkin Bersama", singer: "Judika", img: "tak-mungkin-bersama"),
        songData(alphabet: "T", song: "Teman Bahagia", singer: "Jaz", img: "teman-bahagia"),
        songData(alphabet: "T", song: "Thunder", singer: "Imagine Dragons", img: "thunder"),
        songData(alphabet: "T", song: "Thank U, Next", singer: "Ariana Grande", img: "thank-u-next"),
    ],
    
    "u" : [
        songData(alphabet: "U", song: "Ultralife", singer: "Oh Wonder", img: "ultralife"),
        songData(alphabet: "U", song: "Umbrella", singer: "Rihanna", img: "umbrella"),
        songData(alphabet: "U", song: "Until I Found You", singer: "Stephen Sanchez", img: "until-ifound-you"),
    ],
    
    "v" : [
        songData(alphabet: "V", song: "Viva La Vida", singer: "Coldplay", img: "viva-la-vida"),
        songData(alphabet: "V", song: "Vertigo", singer: "Khalid", img: "vertigo"),
        songData(alphabet: "V", song: "Vulnerable", singer: "Selena Gomez", img: "vulnerable"),
        songData(alphabet: "V", song: "Very Nice", singer: "Seventeen", img: "very-nice"),
    ],
    
    "x" : [
        songData(alphabet: "X", song: "XO", singer: "Beyonce", img: "xo"),
        songData(alphabet: "X", song: "x-ray vision", singer: "Sophie Meiers", img: "xray-vision"),
    ],
    
    "y" : [
        songData(alphabet: "Y", song: "Your Song", singer: "Elton John", img: "your-song"),
        songData(alphabet: "Y", song: "Young, Wild & Free", singer: "Bruno Mars", img: "young-wild-n-free"),
        songData(alphabet: "Y", song: "You're On Your Own Kid", singer: "Taylor Swift", img: "youre-on-your-own-kid"),
    ],
    
    "z" : [
        songData(alphabet: "Z", song: "Zona Nyaman", singer: "Fourtwnty", img: "zona-nyaman"),
        songData(alphabet: "Z", song: "Zero", singer: "Imagine Dragons", img: "zero"),
        songData(alphabet: "Z", song: "Zoom", singer: "Lil Uzi Vert ft. NLE Choppa", img: "zoom"),
    ]
]

func randomSong(alphabet : String) -> songData
{
    let arr = songDataSet[alphabet]
    return arr?.randomElement() ??  songData(alphabet: "r", song: "Ruang Sendiri", singer: "Tulus", img: "adore-you")
}

func generateSongFromName(name : String) -> [songData]
{
    var songList: [songData] = []
    let lowercasedName = name.lowercased()
    for char in lowercasedName {
        songList.append(randomSong(alphabet: String(char)))
    }
    return songList
}

func generateMutableOffset(count : Int) -> [Int]
{
    return [Int](repeating: 500, count: count)
}

func generateHideCardFlag(count : Int) -> [Bool]
{
    return [Bool](repeating: false, count: count)
}

func generateShowCardFlag(count : Int) -> [Bool]
{
    var list = [Bool](repeating: false, count: count-1)
    list.insert(true, at: 0)
    return list
}

struct variables {
    static var songsList = [
        songData(alphabet: "c", song: "Cheating On You", singer: "Charlie Puth", img: "cheating-on-you"),
        songData(alphabet: "l", song: "Love Scenario", singer: "iKon", img: "adore-you"),
        songData(alphabet: "a", song: "Afterglow", singer: "Ed Sheeran", img: "afterglow"),
        songData(alphabet: "r", song: "Ruang Sendiri", singer: "Tulus", img: "ruang-sendiri"),
        songData(alphabet: "a", song: "Anyone", singer: "Justin Bieber", img: "anyone")
    ]
}
