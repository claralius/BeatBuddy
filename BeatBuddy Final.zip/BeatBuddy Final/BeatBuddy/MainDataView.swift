//
//  MainDataView.swift
//  tesapp1
//
//  Created by Kresna Faza R on 14/03/23.
//

import SwiftUI
import AVKit

class SoundManager {
    static let instance = SoundManager()
    
    var player: AVAudioPlayer?
    let choice = ["sound_1", "sound_2", "sound_3"]
    
    func playSound() {
        let soundUrl = choice.randomElement()
        guard let url = Bundle.main.url(forResource: soundUrl, withExtension: ".wav") else {return}
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
        } catch let error{
            print("Error while playing sound \(error.localizedDescription)")
        }
    }
}

struct MainDataView: View {
    @Binding var name: String
    @Binding var generatedSong : [songData]
    @Binding var showCard : [Bool]
    @Binding var hideCard : [Bool]
    @Binding var mutableOffset : [Int]
    @State var onShowList = false
    @State var isPink = true
    
    
    //    Masalah : inisiasi gagal, ketika menggunakan data hasil @State atau @Binding
    //    @State var hideCard = generateHideCardFlag(count: name.count)
    
    
    private func showList(id: Int, delay: Double){
        onShowList = true
        isPink = false
        if onShowList {
            withAnimation(.linear(duration: 1.0)) {
                mutableOffset[id] = 0
                
            }
        }
    }
    
    
    var body: some View {
        ZStack{
            if(isPink)
            {
                Color("primaryPink").edgesIgnoringSafeArea(.all)
            } else {
                Color("indigoAja").edgesIgnoringSafeArea(.all)
            }
            VStack {
                VStack{
                    Text("Hi, " + name)
                        .bold()
                        .frame(maxHeight: 40, alignment: .top)
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)
                    Text("These are some song recommendation you may like based on your name")
                        .font(.title3)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                    
                }
                .frame(maxHeight: 170)
                .padding()
                VStack{
                    ZStack {
                        ForEach((0..<generatedSong.count).reversed(), id: \.self)
                        {
                            if(showCard[$0]){
                                CardView(song: $generatedSong[$0], isDissapear: $hideCard[$0])
                            }
                        }
                        
                        VStack(spacing: 10) {
                            ForEach(0..<generatedSong.count,id: \.self)
                            {
                                if(onShowList){
                                    ListView(songData: $generatedSong[$0])
                                        .offset(y: CGFloat(mutableOffset[$0]))
                                }
                            }
                        }
                        
                    }.onAppear{
                        Task {
                            SoundManager.instance.playSound()
                            showAnimation()
                        }
                        
                    }
                    
                }.frame(height: 500)
                    .padding(30)
            }
        }
    }
    
    private func toggleAfter(delay : Double, id : Int, isShow : Bool)
    {
        if (isShow){
            var _ = Timer.scheduledTimer(withTimeInterval: delay, repeats: false)
            {
                (_) in showCard[id].toggle()
            }
            
        } else {
            var _ = Timer.scheduledTimer(withTimeInterval: delay, repeats: false)
            {
                (_) in hideCard[id].toggle()
            }
        }
    }
    
    private func showAnimation()  {
        
        for i in 0..<generatedSong.count {
            let delay = (Double(i) + 1) * 2.5
            if(i != generatedSong.count - 1){
                toggleAfter(delay: delay, id: i, isShow: false)
                toggleAfter(delay: delay, id: i+1, isShow: true)
            } else {
                toggleAfter(delay: delay, id: i, isShow: false)
                showListAnimation(baseDelay: delay + 1.2)
                
            }
        }
    }
    
    private func showListAnimation(baseDelay: Double) {
        for i in 0..<generatedSong.count {
            let delay = baseDelay + ((Double(i) + 1) * 1.2)
            var _ = Timer.scheduledTimer(withTimeInterval: delay, repeats: false)
            {
                (_) in showList(id: i, delay: delay)
            }
            
        }
    }
}

struct MainDataView_Previews: PreviewProvider {
    static var previews: some View {
        MainDataView(name: .constant("Clara"), generatedSong: .constant(generateSongFromName(name: "Clara")), showCard: .constant(generateShowCardFlag(count: "Clara".count)),hideCard: .constant(generateHideCardFlag(count: "Clara".count)),mutableOffset: .constant(generateMutableOffset(count: "Clara".count)))
    }
}
