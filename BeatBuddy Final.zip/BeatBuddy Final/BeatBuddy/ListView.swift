//
//  ListView.swift
//  tesapp1
//
//  Created by Kresna Faza R on 21/03/23.
//

import SwiftUI

struct ListView: View {
    @Binding var songData : songData
    var body: some View {
        ZStack {
            Rectangle()
            HStack{
                
                Image("list-\(songData.alphabet)")
                    .resizable()
                    .frame(width: 30,height: 30)
                    .padding(.leading,20)
                Image(songData.img)
                    .resizable()
                    .frame(width: 80,height: 80)
                    .cornerRadius(6)
                    .padding(.leading,15)
                VStack {
                    HStack{
                        Text(songData.song)
                            .font(.title2)
                            .foregroundColor(.black)
                            .bold()
                        Spacer()
                    }
                    HStack{
                        
                        
                        Text(songData.singer)
                            .font(.body)
                            .foregroundColor(.gray)
                        Spacer()
                    }
                    Spacer()
                }.padding(.leading,10)
                    .padding(.top,10)
            }
            
        }.frame(height: 100)
            .foregroundColor(.white)
            .cornerRadius(20)
    }
}


struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView(songData: .constant(songData(alphabet: "I", song: "Ruang Sendiri", singer: "Tulus", img: "adore-you")))
    }
}
