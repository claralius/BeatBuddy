//
//  CardView.swift
//  tesapp1
//
//  Created by Kresna Faza R on 21/03/23.
//

import SwiftUI


struct CardView: View {
    @State var isFront: Bool = false
    @State var idx: Int = 0
    @State var backDegree = 0.0
    @State var frontDegree = 90.0 // 90
    @State var isFlipped = false
    @State var offsetToggle = false
    @Binding var song : songData
    @Binding var isDissapear : Bool
    
    let durationAndDelay : CGFloat = 0.2
    
    func flipCard () {
        isFlipped = !isFlipped
        if isFlipped {
            withAnimation(.linear(duration: durationAndDelay)) {
                backDegree = -90
            }
            withAnimation(.linear(duration: durationAndDelay).delay(durationAndDelay)){
                frontDegree = 0
            }
        } else {
            withAnimation(.linear(duration: durationAndDelay)) {
                frontDegree = 90
            }
            withAnimation(.linear(duration: durationAndDelay).delay(durationAndDelay)){
                backDegree = 0
            }
        }
    }
    var body: some View {
        ZStack {
            CardFront( degree: $frontDegree, song: $song)
                .offset(x : offsetToggle ? -350 : 0)
                .onChange(of: isDissapear) { (isDissapear) in
                    withAnimation(.linear(duration: 0.4)){
                        offsetToggle.toggle()
                    }
                }
            CardBack( degree: $backDegree,song: $song)
        }.onAppear {
            Task {
               await waitToFlip()
            }
        }
    }
    
    private func waitToFlip() async {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            flipCard()
        }
    }
}


struct CardBack : View {
    @Binding var degree: Double
    @Binding var song : songData
    var body: some View {
        ZStack{
            ZStack {
                Rectangle()
                VStack{
                    HStack{
                        Image(song.alphabet)
                            .resizable()
                            .frame(width: 35, height: 35)
                            .foregroundColor(.white)
                        Spacer()
                    }.padding(15)
                    Spacer()
                    ZStack{
                        Rectangle()
                        Image(song.alphabet)
                            .resizable()
                            .frame(width: 70, height: 85)
                            .foregroundColor(.white)
                    }
                    .border(.red,width: 2)
                    .frame(width: 170,height: 270)
                    Spacer()
                    HStack{
                        Spacer()
                        Image(song.alphabet)
                            .resizable()
                            .frame(width: 35, height: 35)
                            .foregroundColor(.white)
                            .rotation3DEffect(.degrees(180), axis: (x: 0, y: 0, z: 1))
                        
                    }.padding(15)
                }
            }
            .rotation3DEffect(Angle(degrees: degree), axis: (x: 0, y: 1, z: 0))
            .foregroundColor(Color("backgroundCardBlue"))
            .frame(width: 265,height: 410)
            .cornerRadius(20)
        }
    }
}

struct CardFront : View {
    @Binding var degree: Double
    @Binding var song : songData
    var body: some View {
        ZStack{
            Rectangle()
            
            VStack{
                Image(song.img)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 230)
                    .padding(.bottom,30)
                HStack{
                    Text(song.song)
                        .font(.title2)
                        .foregroundColor(.black)
                        .bold()
                    Spacer()
                }.padding(.leading,20)
                
                HStack{
                    Text(song.singer)
                        .font(.body)
                        .foregroundColor(.gray)
                    Spacer()
                }.padding(.leading,20)
            }
        }.rotation3DEffect(Angle(degrees: degree), axis: (x: 0, y: 1, z: 0))
            .foregroundColor(.white)
            .frame(width: 265,height: 410)
            .cornerRadius(27)
            .shadow(radius: 16, x:16,y: 16)
    }
    
}

struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        CardView(song: .constant(songData(alphabet: "I", song: "Cheating On You", singer: "Charlie Puth", img: "cheating-on-you")), isDissapear: .constant(false))
    }
}
