//
//  splashScreen.swift
//  BeatBuddy
//
//  Created by Clarabella Lius on 24/03/23.
//

import SwiftUI

struct splashScreen: View {
    @State private var isCentered = false
    @State private var descriptionOffset: CGFloat = -400
    @State private var buttonOffset: CGFloat = -800
    @State private var buttonOpacity = 0.0
    
    var body: some View {
        
        NavigationView {
            ZStack (alignment: .center){
                
                LottieIcon(animationName: "logo")
                    .position(x:205, y:250)
                
                VStack{
                    Spacer()
                    Text("BeatBuddy")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(Color("Blue"))
                    //                    .padding(-15)
                        .position(x:195, y:340)
                        .offset(x: isCentered ? 0 : -UIScreen.main.bounds.width, y: 0)
                        .animation(.easeInOut(duration: 4.0))
                        .onAppear {
                            self.isCentered = true
                        }
                    
                    Text("Discover new beats with your name")
                        .font(.title)
                        .fontWeight(.light)
                        .multilineTextAlignment(.center)
                        .bold()
                        .foregroundColor(Color("Blue"))
                        .position(x:195, y:150)
                        .offset(x: descriptionOffset)
                        .animation(.easeInOut(duration: 4.0))
                        .onAppear {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                                
    //                            descriptionVisible = true
                                descriptionOffset = 5
                            }
                        }
                    
                    //Button
                    NavigationLink(destination: scanPage(goToSecondView: false)) {
                        
                        Text("Let's Find Out!")
                            .bold()
                            .frame(width: 350,height: 60)
                            .font(.title)
                            .background(Color("Pink"))
                            .foregroundColor(.white)
                            .cornerRadius(50)
                            .position(x:195, y:120)
                            .offset(y: buttonOffset)
                            .animation(.spring())
                            .onAppear {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 7.0) {
                                    buttonOffset = 0
                                }
                            }
                    }
                    
                }
                
            }.background(Color("White"))
        }
    }
}

struct splashScreen_Previews: PreviewProvider {
    static var previews: some View {
        splashScreen()
    }
}
