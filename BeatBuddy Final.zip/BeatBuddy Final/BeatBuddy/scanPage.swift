//
//  ContentView.swift
//  Scan Page
//
//  Created by Kevin Christanto on 15/03/23.
//

import SwiftUI

struct RotationAnimation: View {
    @State private var isRotating = 0.0
    var body: some View {
        Image("Vinyl")
            .resizable()
            .frame(width: 300, height: 300)
            .padding(.bottom, 15.0)
            .rotationEffect(.degrees(isRotating))
            .onAppear {
                withAnimation(.linear(duration: 1)
                    .speed(0.1).repeatForever(autoreverses: false)) {
                        isRotating = 360.0
                    }
            }
    }
}

struct scanPage: View {
    @State private var presentAlert = false
    @State private var username: String = ""
    @State var goToSecondView: Bool = false
    @State var personData = nameData(name: "a")
    var body: some View {
        ZStack {
            NavigationLink(destination: MainDataView(name: $personData.personName, generatedSong: $personData.songData, showCard: $personData.showCard, hideCard: $personData.hideCard, mutableOffset: $personData.mutableOffset), isActive: $goToSecondView) { EmptyView() }
            Color.yellow.edgesIgnoringSafeArea(.all)
            VStack {
                Text("Wanna personalize your own playlist?")
                    .multilineTextAlignment(.center)
                    .padding(1)
                    .foregroundColor(.black)
                    .font(.system(size: 32))
                    .fontWeight(.bold)
                            
                Text("Beat Buddy helps you discover new songs from your name!")
                    .font(.system(size: 20))
                    .foregroundColor(.white)
                // ini warna nya masi mau diganti lagi
                    .multilineTextAlignment(.center)
                    .fontWeight(.medium)
                
                
                ZStack {
                    RotationAnimation()
                    
                    VStack {
                        HStack {
                            Spacer()
                            Image("Needle")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: 250)
                        }.frame(width: 300)
                        Spacer()
                        
                    }.frame(height: 280)
                    
                }
                
                Image("")
                
                
                Button{
                    presentAlert = true
                } label: {
                    Text("Input Your Name").padding(.horizontal,60)
                        .padding(.vertical,10)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .background(Color.pink)
                        .cornerRadius(20)
                }.alert("Please enter your name.", isPresented: $presentAlert, actions: {
                    TextField("Name", text: $username)
                    
                    
                    
                    Button("Submit", action: {
                        personData = nameData(name: username)
                        goToSecondView = true
                    })
                    Button("Cancel", role: .cancel, action: {
                        
                    })
                })
                
            }
            .padding()
        }
    }
    
}

struct scanPage_Previews: PreviewProvider {
    static var previews: some View {
        scanPage()
    }
}
