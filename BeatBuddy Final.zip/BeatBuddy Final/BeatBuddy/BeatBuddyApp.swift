//
//  BeatBuddyApp.swift
//  BeatBuddy
//
//  Created by Clarabella Lius on 24/03/23.
//

import SwiftUI

@main
struct BeatBuddyApp: App {
    var body: some Scene {
        WindowGroup {
            splashScreen()
        }
    }
}
